package com.java.SpringbootRestfullWebServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestfullWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
